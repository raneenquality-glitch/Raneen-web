package com.raneen.quality

import android.app.Application
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.raneen.quality.data.RaneenDatabase

class RaneenApp : Application() {
    private val migration3to4 = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE photos ADD COLUMN mediaType TEXT NOT NULL DEFAULT 'PHOTO'")
            db.execSQL("ALTER TABLE photos ADD COLUMN fileExtension TEXT NOT NULL DEFAULT 'jpg'")
        }
    }
    // داتابيز واحدة للتطبيق كله. destructive migration مؤقتًا أثناء التطوير (قبل الإصدار لازم Migration حقيقي)
    val db: RaneenDatabase by lazy {
        Room.databaseBuilder(this, RaneenDatabase::class.java, "raneen.db")
            .addMigrations(migration3to4)
            .build()
    }
}
