package com.raneen.quality.data

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.InputStream
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.media.ExifInterface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

/**
 * بيحرق شريط البيانات (الفرع / القسم / التاريخ والوقت / المراقب) جوه بيكسلات الصورة نفسها.
 * الصورة بتتحفظ في مخزن التطبيق الخاص، ومفيش في التطبيق أي طريقة لتعديل الشريط أو الصورة.
 */
object PhotoStamper {
    fun stamp(raw: File, out: File, lines: List<String>): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(raw.path, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
            val decoded = BitmapFactory.decodeFile(raw.path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return false

            val degrees = when (ExifInterface(raw.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            val upright = if (degrees != 0f)
                Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, Matrix().apply { postRotate(degrees) }, true)
            else decoded
            // تصغير لحد 1280 بكسل عشان التخزين (الشريط بيتحرق بعد التصغير فيفضل واضح)
            val longSide = maxOf(upright.width, upright.height)
            val sized = if (longSide > 1280) {
                val k = 1280f / longSide
                Bitmap.createScaledBitmap(upright, (upright.width * k).toInt(), (upright.height * k).toInt(), true)
            } else upright
            val bmp = sized.copy(Bitmap.Config.ARGB_8888, true)

            val canvas = Canvas(bmp)
            val pad = bmp.width * 0.025f
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = bmp.width / 26f
                typeface = Typeface.DEFAULT_BOLD
            }
            val textWidth = (bmp.width - 2 * pad).toInt()
            val layouts = lines.map {
                StaticLayout.Builder.obtain(it, 0, it.length, paint, textWidth)
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setTextDirection(TextDirectionHeuristics.RTL)
                    .build()
            }
            val total = layouts.sumOf { it.height }.toFloat() + pad * 2
            val bg = Paint().apply { color = Color.argb(179, 0, 0, 0) }
            canvas.drawRect(0f, bmp.height - total, bmp.width.toFloat(), bmp.height.toFloat(), bg)
            var y = bmp.height - total + pad
            for (l in layouts) {
                canvas.save()
                canvas.translate(pad, y)
                l.draw(canvas)
                canvas.restore()
                y += l.height
            }

            out.parentFile?.mkdirs()
            FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            true
        } catch (t: Throwable) {
            false
        }
    }
}


/** يحفظ النسخة النهائية في معرض الهاتف بالإضافة لنسخة التقرير داخل التطبيق. */
object PhoneMediaSaver {
    fun save(context: Context, file: File, mediaType: String, displayName: String): Boolean {
        return try {
            val resolver = context.contentResolver
            val isVideo = mediaType == "VIDEO"
            val collection = if (Build.VERSION.SDK_INT >= 29) {
                if (isVideo) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                else MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, if (isVideo) "video/mp4" else "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, if (isVideo) "Movies/Raneen Quality" else "Pictures/Raneen Quality")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values) ?: return false
            try {
                resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } } ?: throw IllegalStateException("no output")
                if (Build.VERSION.SDK_INT >= 29) {
                    val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    resolver.update(uri, done, null, null)
                }
                true
            } catch (t: Throwable) {
                resolver.delete(uri, null, null)
                false
            }
        } catch (t: Throwable) { false }
    }
}
