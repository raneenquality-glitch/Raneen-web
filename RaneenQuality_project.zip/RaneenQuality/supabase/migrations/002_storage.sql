insert into storage.buckets (id,name,public) values ('report-photos','report-photos',false) on conflict (id) do update set public=false;

drop policy if exists raneen_media_read on storage.objects;
create policy raneen_media_read on storage.objects for select to authenticated using (bucket_id='report-photos' and (public.my_role() in ('ADMIN','AREA_MANAGER','DEPT_MANAGER') or (storage.foldername(name))[1]=auth.uid()::text));
drop policy if exists raneen_media_insert on storage.objects;
create policy raneen_media_insert on storage.objects for insert to authenticated with check (bucket_id='report-photos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists raneen_media_update on storage.objects;
create policy raneen_media_update on storage.objects for update to authenticated using (bucket_id='report-photos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists raneen_media_delete on storage.objects;
create policy raneen_media_delete on storage.objects for delete to authenticated using (bucket_id='report-photos' and public.my_role() in ('ADMIN','DEPT_MANAGER'));
