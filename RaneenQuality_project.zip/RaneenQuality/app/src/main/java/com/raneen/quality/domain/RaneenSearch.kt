package com.raneen.quality.domain

/** توحيد النص العربي للبحث: بيشيل التشكيل والتطويل، ويوحّد الهمزات والتاء المربوطة والألف المقصورة والأرقام */
fun normAr(s: String): String {
    val sb = StringBuilder(s.length)
    for (ch in s.lowercase()) {
        val c: Char = when (ch) {
            'أ', 'إ', 'آ', 'ٱ' -> 'ا'
            'ة' -> 'ه'
            'ى' -> 'ي'
            in '٠'..'٩' -> '0' + (ch - '٠')
            in '۰'..'۹' -> '0' + (ch - '۰')
            else -> ch
        }
        val code = c.code
        if (code in 0x064B..0x065F || code == 0x0670 || code == 0x0640) continue
        sb.append(c)
    }
    return sb.toString().trim()
}

/** كل كلمة في البحث لازم تبقى موجودة في أي مكان من الحقول (AND) */
fun matchesQuery(query: String, vararg fields: String?): Boolean {
    val tokens = normAr(query).split(' ').filter { it.isNotBlank() }
    if (tokens.isEmpty()) return true
    val hay = normAr(fields.filterNotNull().joinToString(" "))
    return tokens.all { hay.contains(it) }
}

/** بيقبل أرقام عربي وفاصلة عشرية عربي */
fun parseNum(s: String): Double? = normAr(s).replace(',', '.').replace('٫', '.').toDoubleOrNull()
