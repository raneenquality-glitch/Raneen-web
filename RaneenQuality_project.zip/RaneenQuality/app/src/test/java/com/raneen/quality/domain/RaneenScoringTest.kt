package com.raneen.quality.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class RaneenScoringTest {

    // بند وزنه 4 وعقوبته 2 (زي بند 17 و23 في الأقسام)
    private val doubleItem = ControlDef("c17", "cat1", maxScore = 4.0, penaltyPerViolation = 2.0)

    @Test fun `two violations on a double-penalty item lose the full weight`() {
        assertEquals(4.0, controlLoss(doubleItem, 2), 0.0)
    }

    @Test fun `loss never exceeds the item weight`() {
        assertEquals(4.0, controlLoss(doubleItem, 5), 0.0)
    }

    @Test fun `no violations means no loss`() {
        assertEquals(0.0, controlLoss(doubleItem, 0), 0.0)
    }

    @Test fun `violations are summed across product groups`() {
        val controls = listOf(
            ControlDef("c1", "cat1", 4.0, 1.0),
            ControlDef("c2", "cat1", 6.0, 6.0)
        )
        // c1: مخالفة في مجموعتين = 2 خصم | c2: مفيش مخالفات
        val findings = listOf(
            FindingIn("c1", "g1", 1),
            FindingIn("c1", "g2", 1)
        )
        val s = scoreUnit(controls, findings)
        assertEquals(10.0, s.planned, 0.0)
        assertEquals(8.0, s.actual, 0.0)
        assertEquals(80.0, s.percent, 0.0)
    }

    @Test fun `services style - four sections at weight over four equals full loss`() {
        // بند وزنه 8، كل X بيخصم 2 → 4 X = 8
        val c = ControlDef("s1", "cat1", 8.0, 2.0)
        val findings = (1..4).map { FindingIn("s1", "q$it", 1) }
        val s = scoreUnit(listOf(c), findings)
        assertEquals(0.0, s.actual, 0.0)
    }

    @Test fun `administration style - one X takes the full weight`() {
        val c = ControlDef("a1", "cat1", 10.0, 10.0)
        val s = scoreUnit(listOf(c, ControlDef("a2", "cat1", 90.0, 90.0)), listOf(FindingIn("a1", "", 1)))
        assertEquals(90.0, s.actual, 0.0)
    }

    @Test fun `category breakdown is reported`() {
        val controls = listOf(
            ControlDef("c1", "clean", 4.0, 1.0),
            ControlDef("c2", "display", 4.0, 1.0)
        )
        val s = scoreUnit(controls, listOf(FindingIn("c2", "", 1)))
        assertEquals(4.0, s.byCategory["clean"]!!.actual, 0.0)
        assertEquals(3.0, s.byCategory["display"]!!.actual, 0.0)
    }

    @Test fun `N/A units are excluded from the average`() {
        assertEquals(90.0, kindAverage(listOf(100.0, null, 80.0))!!, 0.0)
    }

    @Test fun `all N/A gives null`() {
        assertNull(kindAverage(listOf(null, null)))
    }
}
