# Raneen Quality

نسخة موحدة من مشروع إدارة الجودة بشركة رنين:
- `app/` تطبيق Android للمراقب.
- `web/index.html` لوحة الويب للأدمن ومدير المنطقة ومدير الإدارة.
- `supabase/migrations/` مخطط قاعدة البيانات وRLS وStorage.
- `supabase/functions/smart-processor/` دالة إدارة المستخدمين.
- `.github/workflows/deploy-web.yml` نشر لوحة الويب على GitHub Pages.

## الوسائط
- الصور تُختم ببيانات الفرع والقسم والتاريخ والوقت والمراقب، وتُحفظ داخل التطبيق وفي معرض الهاتف.
- الفيديو يُلتقط بصيغة MP4، ويُحفظ في الهاتف ويرفع إلى Supabase Storage.
- مسار التخزين: `userId/inspectionId/mediaId.jpg|mp4`.

## Supabase
1. طبّق ملفات `supabase/migrations` على مشروع Supabase.
2. انشر Edge Function باسم `smart-processor`.
3. اضبط secret `SUPABASE_SERVICE_ROLE_KEY` داخل Edge Function فقط. لا تضعه في Android أو `index.html`.
4. تأكد أن `profiles` تحتوي على المستخدم الإداري الأول قبل إدارة باقي المستخدمين.

## GitHub Pages
ارفع المشروع إلى GitHub على branch `main`. الـ workflow ينشر مجلد `web` تلقائيًا.
