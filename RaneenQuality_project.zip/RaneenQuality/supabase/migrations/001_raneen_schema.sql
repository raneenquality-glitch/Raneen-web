create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  name text not null,
  role text not null check (role in ('INSPECTOR','AREA_MANAGER','DEPT_MANAGER','ADMIN')),
  is_active boolean not null default true,
  must_change boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.branches (
  id text primary key,
  code text unique not null,
  name text not null,
  region text,
  is_active boolean not null default true
);

create table if not exists public.catalog_items (
  id text primary key,
  kind text not null check (kind in ('branch','unit','group','category','control')),
  data jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key,
  inspector_id uuid not null references public.profiles(id),
  report_number text not null,
  branch_id text references public.branches(id),
  status text not null default 'SUBMITTED',
  data jsonb not null default '{}'::jsonb,
  audit jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists reports_status_idx on public.reports(status);
create index if not exists reports_inspector_idx on public.reports(inspector_id);

create or replace function public.my_role() returns text language sql stable security definer set search_path=public as $$
  select role from public.profiles where id=auth.uid() and is_active=true limit 1;
$$;

create or replace function public.password_changed() returns void language plpgsql security definer set search_path=public as $$
begin update public.profiles set must_change=false where id=auth.uid(); end; $$;

create or replace function public.replace_catalog(items jsonb) returns void language plpgsql security definer set search_path=public as $$
begin
  if public.my_role() <> 'ADMIN' then raise exception 'forbidden'; end if;
  delete from public.catalog_items;
  insert into public.catalog_items(id,kind,data)
  select x->>'id', x->>'kind', coalesce(x->'data','{}'::jsonb) from jsonb_array_elements(items) x;
  delete from public.branches;
  insert into public.branches(id,code,name,region,is_active)
  select id, coalesce(data->>'code',''), coalesce(data->>'name',''), data->>'region', coalesce((data->>'isActive')::boolean,true)
  from public.catalog_items where kind='branch'
  on conflict(id) do update set code=excluded.code,name=excluded.name,region=excluded.region,is_active=excluded.is_active;
end; $$;

create or replace function public.submit_report(p_id uuid,p_report_number text,p_branch_id text,p_data jsonb) returns void language plpgsql security definer set search_path=public as $$
declare a jsonb; begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  insert into public.reports(id,inspector_id,report_number,branch_id,status,data,audit)
  values(p_id,auth.uid(),p_report_number,p_branch_id,'SUBMITTED',p_data,'[]'::jsonb)
  on conflict(id) do update set report_number=excluded.report_number,branch_id=excluded.branch_id,data=excluded.data,status='SUBMITTED',updated_at=now();
end; $$;

create or replace function public.review_report(p_id uuid,p_action text,p_note text default null) returns void language plpgsql security definer set search_path=public as $$
declare old_audit jsonb; new_status text; actor text; r text; begin
  r:=public.my_role();
  if r not in ('AREA_MANAGER','DEPT_MANAGER','ADMIN') then raise exception 'forbidden'; end if;
  if p_action='REVIEWED' and r not in ('AREA_MANAGER','ADMIN') then raise exception 'area manager required'; end if;
  if p_action='FINAL_APPROVED' and r not in ('DEPT_MANAGER','ADMIN') then raise exception 'department manager required'; end if;
  if p_action='RETURNED' and r not in ('AREA_MANAGER','DEPT_MANAGER','ADMIN') then raise exception 'forbidden'; end if;
  new_status:=p_action;
  select coalesce(audit,'[]'::jsonb) into old_audit from public.reports where id=p_id for update;
  select coalesce(name,'') into actor from public.profiles where id=auth.uid();
  old_audit:=old_audit || jsonb_build_array(jsonb_build_object('id',gen_random_uuid()::text,'action',p_action,'actorName',actor,'actorRole',r,'note',p_note,'at',extract(epoch from now())*1000));
  update public.reports set status=new_status,audit=old_audit,updated_at=now() where id=p_id;
end; $$;

alter table public.profiles enable row level security;
alter table public.branches enable row level security;
alter table public.catalog_items enable row level security;
alter table public.reports enable row level security;

drop policy if exists profiles_self_or_manager on public.profiles;
create policy profiles_self_or_manager on public.profiles for select to authenticated using (id=auth.uid() or public.my_role() in ('ADMIN','AREA_MANAGER','DEPT_MANAGER'));
drop policy if exists branches_read on public.branches;
create policy branches_read on public.branches for select to authenticated using (true);
drop policy if exists catalog_read on public.catalog_items;
create policy catalog_read on public.catalog_items for select to authenticated using (true);
drop policy if exists reports_read on public.reports;
create policy reports_read on public.reports for select to authenticated using (inspector_id=auth.uid() or public.my_role() in ('ADMIN','AREA_MANAGER','DEPT_MANAGER'));

grant execute on function public.my_role() to authenticated;
grant execute on function public.password_changed() to authenticated;
grant execute on function public.submit_report(uuid,text,text,jsonb) to authenticated;
grant execute on function public.review_report(uuid,text,text) to authenticated;
grant execute on function public.replace_catalog(jsonb) to authenticated;
