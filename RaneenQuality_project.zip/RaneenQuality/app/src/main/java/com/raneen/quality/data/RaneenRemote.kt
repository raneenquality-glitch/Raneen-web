package com.raneen.quality.data

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** إعدادات Supabase. الـ publishable key آمن يتحط في التطبيق؛ الحماية الحقيقية بـ RLS على السيرفر. */
object SupabaseConfig {
    const val URL = "https://rdhmulfhwgdjtadpcsge.supabase.co"
    const val KEY = "sb_publishable_7zeqh0Qa5ppXCgqlohLVdA_JwtEEHoT"
    const val ADMIN_FUNCTION = "smart-processor"   // دالة إدارة المستخدمين (admin-users)
    const val BUCKET = "report-photos"
    const val EMAIL_DOMAIN = "raneen.app"
}

/** مفيش إنترنت / السيرفر مش متاح */
class NetworkException(cause: Throwable) : Exception(cause.message, cause)

/** السيرفر رد بخطأ (4xx/5xx) */
class ApiException(val code: Int, val body: String) : Exception("HTTP $code")

class Resp(val code: Int, val bytes: ByteArray) {
    val text: String get() = String(bytes, Charsets.UTF_8)
}

class Session(val access: String, val refresh: String, val expiresAt: Long, val userId: String)

/** عميل HTTP بسيط (من غير مكتبات): Auth + REST + Storage + Edge Function */
class SupabaseRemote(context: Context) {
    private val prefs = context.getSharedPreferences("raneen_session", Context.MODE_PRIVATE)

    fun session(): Session? {
        val a = prefs.getString("a", null) ?: return null
        val r = prefs.getString("r", null) ?: return null
        val u = prefs.getString("u", null) ?: return null
        return Session(a, r, prefs.getLong("e", 0L), u)
    }

    private fun save(s: Session) {
        prefs.edit().putString("a", s.access).putString("r", s.refresh).putLong("e", s.expiresAt).putString("u", s.userId).apply()
    }

    fun clearSession() { prefs.edit().clear().apply() }

    private fun raw(
        method: String, path: String, token: String?, body: ByteArray? = null,
        contentType: String? = null, extra: Map<String, String> = emptyMap(), readTimeout: Int = 30_000
    ): Resp {
        val conn = URL(SupabaseConfig.URL + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = readTimeout
            conn.setRequestProperty("apikey", SupabaseConfig.KEY)
            if (token != null) conn.setRequestProperty("Authorization", "Bearer $token")
            if (contentType != null) conn.setRequestProperty("Content-Type", contentType)
            extra.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code >= 400) throw ApiException(code, String(bytes, Charsets.UTF_8))
            return Resp(code, bytes)
        } catch (e: IOException) {
            throw NetworkException(e)
        } finally {
            conn.disconnect()
        }
    }

    private fun parseSession(j: JSONObject): Session = Session(
        access = j.getString("access_token"),
        refresh = j.getString("refresh_token"),
        expiresAt = System.currentTimeMillis() + j.optLong("expires_in", 3600L) * 1000,
        userId = j.getJSONObject("user").getString("id")
    )

    fun signIn(email: String, password: String): Session {
        val body = JSONObject().put("email", email).put("password", password).toString().toByteArray(Charsets.UTF_8)
        val s = parseSession(JSONObject(raw("POST", "/auth/v1/token?grant_type=password", null, body, "application/json").text))
        save(s)
        return s
    }

    /** بيرجّع access token صالح، ولو قارب على الانتهاء بيجدده */
    @Synchronized
    private fun token(): String {
        val s = session() ?: throw ApiException(401, "no session")
        if (System.currentTimeMillis() < s.expiresAt - 60_000) return s.access
        try {
            val body = JSONObject().put("refresh_token", s.refresh).toString().toByteArray(Charsets.UTF_8)
            val n = parseSession(JSONObject(raw("POST", "/auth/v1/token?grant_type=refresh_token", null, body, "application/json").text))
            save(n)
            return n.access
        } catch (e: ApiException) {
            if (e.code in 400..403) clearSession()
            throw e
        }
    }

    fun get(path: String): String = raw("GET", path, token()).text

    fun post(path: String, json: String): String =
        raw("POST", path, token(), json.toByteArray(Charsets.UTF_8), "application/json").text

    fun rpc(fn: String, json: String): String = post("/rest/v1/rpc/$fn", json)

    fun putUser(json: String) {
        raw("PUT", "/auth/v1/user", token(), json.toByteArray(Charsets.UTF_8), "application/json")
    }

    fun upload(objectPath: String, file: File, contentType: String = when (file.extension.lowercase()) {
        "mp4" -> "video/mp4"
        "png" -> "image/png"
        else -> "image/jpeg"
    }) {
        raw(
            "POST", "/storage/v1/object/${SupabaseConfig.BUCKET}/$objectPath", token(), file.readBytes(),
            contentType, mapOf("x-upsert" to "true"), 180_000
        )
    }

    fun download(objectPath: String, dest: File) {
        val r = raw("GET", "/storage/v1/object/authenticated/${SupabaseConfig.BUCKET}/$objectPath", token(), readTimeout = 90_000)
        dest.parentFile?.mkdirs()
        dest.writeBytes(r.bytes)
    }

    /** حذف صورة من السحابة (لو مش موجودة أصلًا مفيش مشكلة) */
    fun deleteObject(objectPath: String) {
        try {
            raw("DELETE", "/storage/v1/object/${SupabaseConfig.BUCKET}/$objectPath", token())
        } catch (e: ApiException) {
            if (e.code != 404 && e.code != 400) throw e
        }
    }

    fun callAdmin(json: String): JSONObject =
        JSONObject(raw("POST", "/functions/v1/${SupabaseConfig.ADMIN_FUNCTION}", token(), json.toByteArray(Charsets.UTF_8), "application/json").text)
}
