package com.raneen.quality.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import java.util.UUID

/**
 * تعديلات الأدمن على الفروع والأقسام والضوابط. بتتحفظ محليًا وبعدين بتتبعت للسيرفر (sync).
 * "الحذف" للأقسام/الكاتجري/المجموعات/الضوابط = إخفاء (isActive=0) عشان التقارير القديمة تفضل سليمة.
 * الفرع بيتحذف فعليًا لو مفيش عليه زيارات، وإلا بيتقفل.
 */
class CatalogAdminRepository(
    private val db: RaneenDatabase,
    private val seed: SeedLoader,
    private val sync: SyncRepository
) {
    private val dao = db.catalogDao()

    private fun changed() { sync.markCatalogDirty(); sync.kick() }

    fun units(): Flow<List<EvaluationUnitEntity>> = dao.observeUnits()
    fun unit(id: String) = dao.observeUnit(id)
    fun groups(u: String) = dao.observeGroups(u)
    fun categories(u: String) = dao.observeCategories(u)
    fun controls(u: String) = dao.observeControls(u)
    fun weightSum(u: String) = dao.observeWeightSum(u)
    fun branches() = dao.observeAllBranches()

    // ───────── الفروع ─────────
    suspend fun saveBranch(existing: BranchEntity?, code: String, name: String, region: String, active: Boolean): String? {
        if (code.isBlank() || name.isBlank()) return "اكتب كود واسم الفرع"
        val id = existing?.id ?: UUID.randomUUID().toString()
        if (dao.codeTaken(code.trim(), id) > 0) return "الكود ده مستخدم لفرع تاني"
        dao.upsertBranches(listOf(BranchEntity(id, code.trim(), name.trim(), region.trim(), active)))
        changed()
        return null
    }

    suspend fun deleteBranch(b: BranchEntity): String? {
        if (dao.inspectionsOfBranch(b.id) > 0) return "الفرع عليه زيارات سابقة — اقفله (معطّل) بدل الحذف"
        dao.deleteBranch(b.id)
        changed()
        return null
    }

    // ───────── الأقسام / الإدارات ─────────
    suspend fun saveUnit(existing: EvaluationUnitEntity?, name: String, kind: String): String? {
        if (name.isBlank()) return "اكتب الاسم"
        val u = existing?.copy(name = name.trim(), kind = kind) ?: EvaluationUnitEntity(
            id = UUID.randomUUID().toString(), templateId = "main", name = name.trim(), kind = kind,
            scoringMode = "X_COUNT", sortOrder = dao.maxUnitSort() + 1
        )
        dao.upsertUnits(listOf(u))
        changed()
        return null
    }

    suspend fun deleteUnit(id: String) {
        db.withTransaction {
            dao.hideControlsOfUnit(id); dao.hideCategoriesOfUnit(id); dao.hideGroupsOfUnit(id); dao.hideUnit(id)
        }
        changed()
    }

    // ───────── المجموعات (مجموعات منتجات / ق1–ق4) ─────────
    suspend fun saveGroup(unitId: String, existing: ProductGroupEntity?, name: String): String? {
        if (name.isBlank()) return "اكتب اسم المجموعة"
        val g = existing?.copy(name = name.trim()) ?: ProductGroupEntity(
            UUID.randomUUID().toString(), unitId, name.trim(), dao.maxGroupSort(unitId) + 1
        )
        dao.upsertGroups(listOf(g))
        changed()
        return null
    }

    suspend fun deleteGroup(id: String) { dao.hideGroup(id); changed() }

    // ───────── الكاتجري ─────────
    suspend fun saveCategory(unitId: String, existing: CategoryEntity?, name: String): String? {
        if (name.isBlank()) return "اكتب اسم الكاتجري"
        val c = existing?.copy(name = name.trim()) ?: CategoryEntity(
            UUID.randomUUID().toString(), unitId, name.trim(), dao.maxCategorySort(unitId) + 1
        )
        dao.upsertCategories(listOf(c))
        changed()
        return null
    }

    suspend fun deleteCategory(id: String) {
        db.withTransaction { dao.hideControlsOfCategory(id); dao.hideCategory(id) }
        changed()
    }

    // ───────── الضوابط ─────────
    /** census = ضابط حصر (عدد من غير درجة): وزنه صفر ومش بيتخصم منه */
    suspend fun saveControl(
        unitId: String, existing: ControlEntity?, categoryId: String, text: String, hint: String,
        weight: Double?, penalty: Double?, photoRequired: Boolean, perGroup: Boolean, census: Boolean = false
    ): String? {
        if (categoryId.isBlank()) return "اختر الكاتجري"
        if (text.isBlank()) return "اكتب نص الضابط"
        val w: Double
        val pen: Double
        if (census) {
            w = 0.0; pen = 1.0
        } else {
            if (weight == null || weight <= 0) return "الوزن لازم يكون رقم أكبر من صفر"
            if (penalty == null || penalty <= 0) return "الخصم لكل مخالفة لازم يكون رقم أكبر من صفر"
            w = weight; pen = penalty
        }
        val photo = if (census) false else photoRequired
        val h = hint.trim().ifBlank { null }
        val c = existing?.copy(
            categoryId = categoryId, text = text.trim(), maxScore = w, penaltyPerViolation = pen,
            photoRequired = photo, perGroup = perGroup, hint = h
        ) ?: ControlEntity(
            id = UUID.randomUUID().toString(), categoryId = categoryId, text = text.trim(), maxScore = w,
            penaltyPerViolation = pen, photoRequired = photo, perGroup = perGroup, hint = h,
            sortOrder = dao.maxControlNo(unitId) + 1
        )
        dao.upsertControls(listOf(c))
        changed()
        return null
    }

    suspend fun deleteControl(id: String) { dao.hideControl(id); changed() }

    suspend fun resetCatalog() { seed.reseed(); changed() }
}
