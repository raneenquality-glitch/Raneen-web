package com.raneen.quality.data

import androidx.room.*

// ملاحظة: كل الـ IDs من نوع String (UUID) عشان المزامنة ومنع التكرار (بند 23 و41 في المواصفات)

// ───────────── الإعدادات (بيديرها الأدمن / مدير الرقابة) ─────────────

/** نوع التقرير: تفتيش المعرض / صيانة / مراجعة الإدارات المساعدة (بند 39) */
@Entity(tableName = "templates")
data class TemplateEntity(
    @PrimaryKey val id: String,
    val name: String,
    val isActive: Boolean = true
)

/**
 * "وحدة مُقيَّمة" من 100. kind بيفرّق بين:
 *  - SECTION: أقسام المعرض (منزلي/ألعاب/مفروشات/كهرباء) + الخدمات (مقسومة ق1–ق4) + مدير المعرض
 *  - ADMINISTRATION: الإدارات المساعدة (كاشير/أمن/كاميرات/...) — مش أقسام، وملهاش مجموعات منتجات
 * التقييم النهائي بيحسب متوسط كل kind لوحده.
 */
@Entity(
    tableName = "evaluation_units",
    foreignKeys = [ForeignKey(TemplateEntity::class, ["id"], ["templateId"])],
    indices = [Index("templateId")]
)
data class EvaluationUnitEntity(
    @PrimaryKey val id: String,
    val templateId: String,
    val name: String,
    val kind: String,           // "SECTION" | "ADMINISTRATION"
    val scoringMode: String = "X_COUNT", // X_COUNT: مربع X لكل ضابط (الأقسام العادية + الخدمات + الإدارات المساعدة) | BINARY: مخالف/غير مخالف (مدير المعرض فقط)
    val sortOrder: Int = 0,
    val isActive: Boolean = true
)

/** مجموعة داخل الوحدة: مجموعة منتجات (تيفال، زجاج...) أو قسم في الخدمات (ق1–ق4). الإدارات المساعدة ملهاش مجموعات. */
@Entity(
    tableName = "product_groups",
    foreignKeys = [ForeignKey(EvaluationUnitEntity::class, ["id"], ["unitId"])],
    indices = [Index("unitId")]
)
data class ProductGroupEntity(
    @PrimaryKey val id: String,
    val unitId: String,
    val name: String,
    val sortOrder: Int = 0,
    val isActive: Boolean = true
)

/**
 * كاتجري: النظافة / تنسيق العرض / التسعير... ملك للقسم (unitId) لأن الكهرباء
 * ليها بنود وأوزان مختلفة عن باقي الأقسام (26 بند، الخدمة 14 والفريق 8).
 */
@Entity(
    tableName = "categories",
    foreignKeys = [ForeignKey(EvaluationUnitEntity::class, ["id"], ["unitId"])],
    indices = [Index("unitId")]
)
data class CategoryEntity(
    @PrimaryKey val id: String,
    val unitId: String,
    val name: String,
    val sortOrder: Int = 0,
    val isActive: Boolean = true
)

/**
 * الضابط/البند.
 * maxScore: وزنه (4 / 2 / 5 ...)
 * penaltyPerViolation: 1 عادي، 2 للبنود اللي "الخطأ فيها بدرجتين" (17 و23)
 */
@Entity(
    tableName = "controls",
    foreignKeys = [ForeignKey(CategoryEntity::class, ["id"], ["categoryId"])],
    indices = [Index("categoryId")]
)
data class ControlEntity(
    @PrimaryKey val id: String,
    val categoryId: String,
    val text: String,
    val maxScore: Double,
    val penaltyPerViolation: Double = 1.0,
    val photoRequired: Boolean = true,
    val perGroup: Boolean = false,   // true = المخالفة بتتسجل على مجموعة منتجات/قسم فرعي (groupId)
    val hint: String? = null,        // ملاحظة الإكسيل للعرض للمراقب فقط (مش بتأثر على الحساب)
    val sortOrder: Int = 0,
    val isActive: Boolean = true
)

@Entity(tableName = "branches")
data class BranchEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val region: String,
    val isActive: Boolean = true
)

// ───────────── بيانات الزيارة (بتتكتب أثناء التفتيش) ─────────────

@Entity(
    tableName = "inspections",
    indices = [Index("branchId"), Index("status"), Index("syncState")]
)
data class InspectionEntity(
    @PrimaryKey val id: String,        // UUID
    val reportNumber: String,          // RQ-2026-000125
    val templateId: String,
    val branchId: String,
    val inspectorId: String,
    val visitDate: Long,               // epoch millis
    val visitNumber: String? = null,   // رقم الزيارة/الشهر
    val status: String = "DRAFT",      // DRAFT|SUBMITTED|UNDER_REVIEW|RETURNED|REVIEWED|FINAL_APPROVED
    val notes: String? = null,
    val syncState: String = "LOCAL"    // LOCAL|SYNCING|SYNCED
)

/** القسم داخل الزيارة — isNA لما القسم مش موجود بالفرع (زي الأثاث N/A في الإكسيل) */
@Entity(
    tableName = "inspection_units",
    primaryKeys = ["inspectionId", "unitId"],
    foreignKeys = [ForeignKey(InspectionEntity::class, ["id"], ["inspectionId"], onDelete = ForeignKey.CASCADE)]
)
data class InspectionUnitEntity(
    val inspectionId: String,
    val unitId: String,
    val isNA: Boolean = false
)

/**
 * مخالفة على (قسم + ضابط + مجموعة منتجات).
 * كل ضغطة X = violationCount++ (ده الربط بين فكرة X في المواصفات وأوزان الإكسيل).
 * groupId = "" لو الضابط مش مرتبط بمجموعة (مثلًا الخدمات/الإدارات).
 * ملاحظة: بنستخدم "" بدل NULL لأن SQLite بيعتبر كل NULL مختلف في الـ UNIQUE.
 */
@Entity(
    tableName = "findings",
    foreignKeys = [ForeignKey(InspectionEntity::class, ["id"], ["inspectionId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["inspectionId", "unitId", "controlId", "groupId"], unique = true)]
)
data class FindingEntity(
    @PrimaryKey val id: String,
    val inspectionId: String,
    val unitId: String,
    val controlId: String,
    val groupId: String = "",
    val violationCount: Int = 0,
    val note: String? = null
)

@Entity(
    tableName = "photos",
    foreignKeys = [ForeignKey(FindingEntity::class, ["id"], ["findingId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("findingId")]
)
data class PhotoEntity(
    @PrimaryKey val id: String,
    val findingId: String,
    val filePath: String,      // النسخة الموثقة (فيها شريط الفرع/القسم/التاريخ)
    val capturedAt: Long,
    val syncState: String = "LOCAL",
    val mediaType: String = "PHOTO",   // PHOTO | VIDEO
    val fileExtension: String = "jpg"
)

/** سجل الإجراءات على التقرير: إرسال / مراجعة / إعادة / اعتماد */
@Entity(tableName = "audit_log", indices = [Index("inspectionId")])
data class AuditEntity(
    @PrimaryKey val id: String,
    val inspectionId: String,
    val action: String,      // SUBMITTED|RESUBMITTED|REVIEWED|RETURNED|FINAL_APPROVED
    val actorName: String,
    val actorRole: String,
    val note: String? = null,
    val at: Long
)

// (Users / Roles / Permissions / ReportReviews / AuditLogs / SyncQueue / Notifications
//  زي ما هي في المواصفات — مش بتأثر على منطق الدرجات.)
