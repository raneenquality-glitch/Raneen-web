package com.raneen.quality.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.*
import com.raneen.quality.domain.UnitScore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ───────────── كارت تقرير في القوائم ─────────────
@Composable
fun ReportRowCard(row: ReportRow, showInspector: Boolean, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(row.branchName.ifBlank { "فرع محذوف" }, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                StatusChip(row.status)
            }
            Text("${row.reportNumber}  ·  ${fmtDate(row.visitDate)}", style = MaterialTheme.typography.bodySmall)
            if (showInspector) Text("المراقب: ${row.inspectorName}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ───────────── الرئيسية للمراقب: زيارة جديدة + زياراتي ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InspectorHome(
    user: UserEntity, reports: ReportRepository, sync: SyncRepository,
    onNew: () -> Unit, onOpen: (ReportRow) -> Unit, onLogout: () -> Unit
) {
    val rows by remember { reports.rows() }.collectAsState(initial = emptyList())
    val mine = rows.filter { it.inspectorId == user.id }
    Scaffold(topBar = {
        TopAppBar(title = { Text("إدارة الجودة بشركة رنين") }, actions = { TextButton(onClick = onLogout) { Text("خروج") } })
    }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.bodyMedium)
                SyncBar(sync)
                Spacer(Modifier.height(8.dp))
                Button(onClick = onNew, modifier = Modifier.fillMaxWidth()) { Text("+ زيارة تفتيش جديدة") }
                Spacer(Modifier.height(8.dp))
                Text("زياراتي", style = MaterialTheme.typography.titleMedium)
            }
            if (mine.isEmpty()) item { Text("لسه معندكش زيارات.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(mine, key = { it.id }) { ReportRowCard(it, false) { onOpen(it) } }
        }
    }
}

// ───────────── اختيار الفرع لبدء زيارة ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchPickerScreen(repo: InspectionRepository, inspectorId: String, onBack: () -> Unit, onStarted: (String) -> Unit) {
    val branches by remember(repo) { repo.branches() }.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var starting by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(title = { Text("اختر الفرع") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } })
    }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("اختر الفرع لبدء زيارة تفتيش", style = MaterialTheme.typography.titleMedium) }
            if (branches.isEmpty()) item { Text("مفيش فروع. الأدمن لازم يضيف فروع الأول.", color = MaterialTheme.colorScheme.error) }
            items(branches, key = { it.id }) { b ->
                Card(Modifier.fillMaxWidth().clickable(enabled = !starting) {
                    starting = true
                    scope.launch {
                        val number = "RQ-2026-" + (System.currentTimeMillis() % 1_000_000).toString().padStart(6, '0')
                        onStarted(repo.startInspection(b.id, inspectorId, number))
                    }
                }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(b.name, style = MaterialTheme.typography.titleMedium)
                        Text("${b.code} - ${b.region}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

// ───────────── أقسام الزيارة (درجات لحظية + N/A + مراجعة) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitsScreen(
    user: UserEntity, repo: InspectionRepository, reports: ReportRepository, inspectionId: String,
    onOpen: (String, String) -> Unit, onReview: () -> Unit, onDeleted: () -> Unit
) {
    val units by remember(repo) { repo.units() }.collectAsState(initial = emptyList())
    val insp by remember(inspectionId) { repo.inspectionFlow(inspectionId) }.collectAsState(initial = null)
    val states by remember(inspectionId) { repo.unitStates(inspectionId) }.collectAsState(initial = emptyList())
    val findings by remember(inspectionId) { repo.allFindings(inspectionId) }.collectAsState(initial = emptyList())
    val audit by remember(inspectionId) { reports.audit(inspectionId) }.collectAsState(initial = emptyList())
    val scores by produceState<Map<String, UnitScore>>(emptyMap(), findings) { value = repo.unitScores(inspectionId) }
    val scope = rememberCoroutineScope()
    var confirmDelete by remember { mutableStateOf(false) }

    val editable = insp?.let { Status.editable(it.status) } ?: false
    val naIds = states.filter { it.isNA }.map { it.unitId }.toSet()
    val returnNote = if (insp?.status == Status.RETURNED) audit.lastOrNull { it.action == "RETURNED" }?.note else null

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("اختر القسم أو الإدارة") }, actions = {
                if (insp?.status == Status.DRAFT) TextButton(onClick = { confirmDelete = true }) {
                    Text("حذف الزيارة", color = MaterialTheme.colorScheme.error)
                }
            })
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(onClick = onReview, modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(if (editable) "مراجعة وإرسال التقرير" else "عرض التقرير")
                }
            }
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (returnNote != null) item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                    Column(Modifier.padding(12.dp)) {
                        Text("التقرير اترجّع للتعديل", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                        Text(returnNote)
                    }
                }
            }
            item { Text("الأقسام", style = MaterialTheme.typography.titleMedium) }
            items(units.filter { it.kind == "SECTION" }, key = { it.id }) { u ->
                UnitCard(u, scores[u.id], u.id in naIds, editable, { onOpen(u.id, u.name) }) { na ->
                    scope.launch { repo.setNA(inspectionId, u.id, na) }
                }
            }
            item { Spacer(Modifier.height(8.dp)); Text("الإدارات المساعدة", style = MaterialTheme.typography.titleMedium) }
            items(units.filter { it.kind == "ADMINISTRATION" }, key = { it.id }) { u ->
                UnitCard(u, scores[u.id], u.id in naIds, editable, { onOpen(u.id, u.name) }) { na ->
                    scope.launch { repo.setNA(inspectionId, u.id, na) }
                }
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("حذف الزيارة؟") },
        text = { Text("هتتمسح الزيارة وكل مخالفاتها وصورها من الجهاز. مينفعش تتراجع.") },
        confirmButton = {
            TextButton(onClick = {
                scope.launch { if (reports.deleteDraft(inspectionId, user) == null) onDeleted() }
                confirmDelete = false
            }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء") } }
    )
}

@Composable
private fun UnitCard(
    unit: EvaluationUnitEntity, score: UnitScore?, isNA: Boolean, editable: Boolean,
    onOpen: () -> Unit, onNA: (Boolean) -> Unit
) {
    Card(Modifier.fillMaxWidth().clickable(enabled = !isNA, onClick = onOpen)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(unit.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (isNA) "غير موجود بالفرع" else score?.let { "${fmtScore(it.actual)} / ${fmtScore(it.planned)}" } ?: "",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (editable) {
                Checkbox(checked = isNA, onCheckedChange = onNA)
                Text("N/A", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

// ───────────── تفاصيل التقرير (مراجعة قبل الإرسال + اعتماد المديرين + تصدير) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportDetailScreen(
    user: UserEntity, reports: ReportRepository, inspectionId: String,
    onBack: () -> Unit, onEdit: () -> Unit, onChanged: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val insp by remember(inspectionId) { reports.inspectionFlow(inspectionId) }.collectAsState(initial = null)
    val audit by remember(inspectionId) { reports.audit(inspectionId) }.collectAsState(initial = emptyList())
    var refresh by remember { mutableStateOf(0) }
    val data by produceState<ReportData?>(null, insp?.status, refresh) { value = reports.build(inspectionId) }

    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var confirmSubmit by remember { mutableStateOf(false) }
    var confirmDeletePhotos by remember { mutableStateOf(false) }
    var returning by remember { mutableStateOf(false) }
    var reason by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<PhotoEntity?>(null) }

    fun act(block: suspend () -> String?) {
        scope.launch {
            busy = true
            error = block()
            busy = false
            if (error == null) onChanged()
        }
    }

    fun approveFinal() {
        scope.launch {
            busy = true
            val (e, note) = reports.finalApprove(inspectionId, user)
            busy = false
            error = e
            info = note
            if (e == null) onChanged()
        }
    }

    fun export(kind: String) {
        val d = data ?: return
        scope.launch {
            try {
                val (file, mime) = withContext(Dispatchers.IO) {
                    when (kind) {
                        "pdf" -> ReportExporter.pdf(context, d) to ReportExporter.MIME_PDF
                        "docx" -> ReportExporter.docx(context, d) to ReportExporter.MIME_DOCX
                        "zip" -> ReportExporter.photosZip(context, d)?.let { it to "application/zip" }
                            ?: throw IllegalStateException("no photos")
                        else -> ReportExporter.xlsx(context, d) to ReportExporter.MIME_XLSX
                    }
                }
                ReportExporter.share(context, file, mime)
            } catch (e: IllegalStateException) {
                error = "مفيش صور محفوظة على الجهاز للتقرير ده"
            } catch (e: Exception) {
                error = "تعذّر إنشاء الملف"
            }
        }
    }

    val i = insp
    val canSubmit = user.role == Roles.INSPECTOR && i != null && i.inspectorId == user.id && Status.editable(i.status)
    val canArea = user.role == Roles.AREA_MANAGER && i?.status == Status.SUBMITTED
    val canDept = user.role == Roles.DEPT_MANAGER && i?.status == Status.REVIEWED

    Scaffold(topBar = {
        TopAppBar(title = { Text("تقرير الزيارة") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } })
    }) { padding ->
        val d = data
        if (d == null || i == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Scaffold
        }
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // الترويسة
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(d.branchName.ifBlank { "فرع محذوف" }, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                            StatusChip(i.status)
                        }
                        Text("رقم التقرير: ${i.reportNumber}")
                        Text("تاريخ الزيارة: ${fmtDate(i.visitDate)}")
                        Text("المراقب: ${d.inspectorName}")
                        Text(Status.label(i.status), color = statusColor(i.status), fontWeight = FontWeight.Bold)
                        Text(
                            when (i.syncState) {
                                "SYNCED" -> "تمت المزامنة مع السيرفر."
                                "PENDING" -> "في انتظار الرفع للسيرفر — هيترفع لوحده أول ما يبقى فيه إنترنت."
                                else -> "محفوظ على الجهاز."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            // المتوسطات
            item {
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(fmtPct(d.sectionsAvg), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("متوسط الأقسام", style = MaterialTheme.typography.bodySmall)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(fmtPct(d.adminsAvg), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("متوسط الإدارات", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            // تحذير الصور الناقصة
            if (d.missingPhotos.isNotEmpty()) item {
                Text("⚠ فيه ${d.missingPhotos.size} مخالفة محتاجة صورة ومفيش عليها.", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }
            // سبب الإعادة
            if (i.status == Status.RETURNED) audit.lastOrNull { it.action == "RETURNED" }?.let { a ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                        Column(Modifier.padding(12.dp)) {
                            Text("سبب الإعادة (${a.actorName}):", fontWeight = FontWeight.Bold, color = Color(0xFFC62828))
                            Text(a.note ?: "")
                        }
                    }
                }
            }
            // الدرجات
            item { Text("الدرجات", style = MaterialTheme.typography.titleMedium) }
            items(d.units, key = { "u_" + it.unit.id }) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(l.unit.name, Modifier.weight(1f))
                    Text(
                        if (l.isNA) "N/A" else "${fmtScore(l.score!!.actual)} / ${fmtScore(l.score.planned)}  ·  ${l.violationCount} مخالفة",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
            // المخالفات
            item { Text("المخالفات (${d.violations.size})", style = MaterialTheme.typography.titleMedium) }
            if (d.violations.isEmpty()) item { Text("لا توجد مخالفات.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            d.violations.groupBy { it.unitName }.forEach { (unitName, list) ->
                item(key = "h_$unitName") { Text(unitName, fontWeight = FontWeight.Bold, color = Color(0xFFA00000)) }
                items(list, key = { it.findingId }) { v ->
                    val photos = d.photosByFinding[v.findingId].orEmpty()
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${v.controlNo}. ${v.controlText}")
                            val sub = listOfNotNull(v.categoryName, v.groupName?.takeIf { it.isNotBlank() }).joinToString(" · ")
                            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            val live = photos.filter { it.syncState != "PURGED" && it.syncState != "MISSING" }
                            if (live.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(live, key = { it.id }) { p -> Thumb(p.filePath, 72.dp) { preview = p } }
                            } else if (photos.isNotEmpty()) Text(if (user.id == i.inspectorId) "الصور اتمسحت من موبايلك" else "الصور محفوظة على موبايل المراقب", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            else if (v.photoRequired) Text("⚠ بدون صورة", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            // ضوابط الحصر
            if (d.census.isNotEmpty()) {
                item { Text("ضوابط الحصر", style = MaterialTheme.typography.titleMedium) }
                d.census.groupBy { it.unitName }.forEach { (unitName, list) ->
                    item(key = "ch_$unitName") { Text(unitName, fontWeight = FontWeight.Bold, color = Color(0xFFA00000)) }
                    items(list, key = { it.unitId + "|" + it.controlId }) { c ->
                        Card(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(c.controlText)
                                    Text(c.categoryName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(c.expr, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            // سجل المراجعة
            if (audit.isNotEmpty()) {
                item { Text("سجل المراجعة", style = MaterialTheme.typography.titleMedium) }
                items(audit, key = { it.id }) { a ->
                    Column {
                        Text("${Status.actionLabel(a.action)} — ${a.actorName} (${Roles.label(a.actorRole)})", style = MaterialTheme.typography.bodyMedium)
                        Text(fmtDate(a.at) + (a.note?.let { "  ·  $it" } ?: ""), style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            info?.let { item { Text(it, color = Color(0xFF1D7A4D), fontWeight = FontWeight.Bold) } }
            // الإجراءات حسب الدور والحالة
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (canSubmit) {
                        Button(onClick = { confirmSubmit = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إرسال التقرير") }
                        OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth()) { Text("رجوع للتعديل") }
                    }
                    if (canArea) {
                        Button(onClick = { act { reports.areaApprove(inspectionId, user) } }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("اعتماد المراجعة") }
                        OutlinedButton(onClick = { reason = ""; returning = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إعادة للمراقب") }
                    }
                    if (canDept) {
                        Button(onClick = { approveFinal() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("الاعتماد النهائي") }
                        OutlinedButton(onClick = { reason = ""; returning = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("إعادة للمراقب") }
                    }
                    Text("تصدير ومشاركة", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { export("pdf") }, modifier = Modifier.weight(1f)) { Text("PDF") }
                        OutlinedButton(onClick = { export("docx") }, modifier = Modifier.weight(1f)) { Text("Word") }
                        OutlinedButton(onClick = { export("xlsx") }, modifier = Modifier.weight(1f)) { Text("Excel") }
                    }
                    val hasLocalPhotos = d.photosByFinding.values.flatten().any { it.syncState != "PURGED" && it.syncState != "MISSING" }
                    if (user.role == Roles.INSPECTOR && i.inspectorId == user.id && !Status.editable(i.status) && i.syncState != "PENDING" && hasLocalPhotos) {
                        OutlinedButton(onClick = { confirmDeletePhotos = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("مسح صور التقرير من موبايلي", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    OutlinedButton(onClick = { export("zip") }, modifier = Modifier.fillMaxWidth()) { Text("تحميل الصور الأصلية (ZIP)") }
                    Text("التلات ملفات فيهم الصور المتاحة على الجهاز.", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        if (confirmSubmit) AlertDialog(
            onDismissRequest = { confirmSubmit = false },
            title = { Text("إرسال التقرير؟") },
            text = {
                Text(
                    if (d.missingPhotos.isNotEmpty()) "فيه ${d.missingPhotos.size} مخالفة محتاجة صورة ومفيش عليها. تبعت برضو؟ مش هتقدر تعدّل بعد الإرسال."
                    else "هيتبعت لمدير المنطقة ومش هتقدر تعدّل بعد كده. متأكد؟"
                )
            },
            confirmButton = { TextButton(onClick = { confirmSubmit = false; act { reports.submit(inspectionId, user) } }) { Text("إرسال") } },
            dismissButton = { TextButton(onClick = { confirmSubmit = false }) { Text("إلغاء") } }
        )
        if (confirmDeletePhotos) AlertDialog(
            onDismissRequest = { confirmDeletePhotos = false },
            title = { Text("مسح الصور من موبايلك؟") },
            text = {
                Text("الصور هتتمسح من الموبايل ده بس. لو التقرير لسه ماتعتمدش نهائيًا، نسختها على السيرفر هتفضل لحد الاعتماد النهائي، وبعد كده الصور الأصلية هتفضل في أرشيف مدير الإدارة. صدّر ZIP الصور الأول لو عايز نسخة.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmDeletePhotos = false
                    scope.launch { error = reports.deleteMyPhotos(inspectionId, user); refresh++ }
                }) { Text("مسح", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDeletePhotos = false }) { Text("إلغاء") } }
        )
        if (returning) AlertDialog(
            onDismissRequest = { returning = false },
            title = { Text("سبب الإعادة") },
            text = { OutlinedTextField(value = reason, onValueChange = { reason = it }, label = { Text("اكتب السبب (إجباري)") }, minLines = 2) },
            confirmButton = {
                TextButton(onClick = {
                    val r = reason
                    returning = false
                    act { reports.returnReport(inspectionId, user, r) }
                }) { Text("إعادة") }
            },
            dismissButton = { TextButton(onClick = { returning = false }) { Text("إلغاء") } }
        )
        preview?.let { PhotoDialog(it, false, {}, { preview = null }) }
    }
}

// ───────────── قائمة التقارير (مدير المنطقة / مدير الإدارة / الأدمن) ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsListScreen(
    title: String, user: UserEntity, reports: ReportRepository, sync: SyncRepository,
    leaveLabel: String, onLeave: () -> Unit, onOpen: (ReportRow) -> Unit
) {
    val rows by remember { reports.rows() }.collectAsState(initial = emptyList())
    fun needsAction(r: ReportRow) = (user.role == Roles.AREA_MANAGER && r.status == Status.SUBMITTED) ||
            (user.role == Roles.DEPT_MANAGER && r.status == Status.REVIEWED)
    val isManager = user.role == Roles.AREA_MANAGER || user.role == Roles.DEPT_MANAGER
    var onlyPending by remember { mutableStateOf(isManager) }
    // المراقب مسوّدته مش المفروض تظهر للمديرين قبل الإرسال
    val visible = rows.filter { it.status != Status.DRAFT }.filter { !onlyPending || needsAction(it) }

    Scaffold(topBar = {
        TopAppBar(title = { Text(title) }, actions = { TextButton(onClick = onLeave) { Text(leaveLabel) } })
    }) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Text("${user.name} · ${Roles.label(user.role)}", style = MaterialTheme.typography.bodyMedium)
                SyncBar(sync)
                if (isManager) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = onlyPending, onClick = { onlyPending = true }, label = { Text("تحتاج إجراء") })
                    FilterChip(selected = !onlyPending, onClick = { onlyPending = false }, label = { Text("الكل") })
                }
            }
            if (visible.isEmpty()) item { Text("مفيش تقارير.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            items(visible, key = { it.id }) { ReportRowCard(it, true) { onOpen(it) } }
        }
    }
}
