import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const url = Deno.env.get('SUPABASE_URL')!
const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const admin = createClient(url, serviceKey)

Deno.serve(async (req) => {
  try {
    const auth = req.headers.get('Authorization') || ''
    const token = auth.replace('Bearer ', '')
    const caller = await admin.auth.getUser(token)
    if (!caller.data.user) return new Response(JSON.stringify({error:'not authenticated'}), {status:401})
    const {data: profile} = await admin.from('profiles').select('role').eq('id', caller.data.user.id).single()
    if (profile?.role !== 'ADMIN') return new Response(JSON.stringify({error:'forbidden'}), {status:403})
    const body = await req.json()
    if (body.action === 'create') {
      const email = `${String(body.username).trim().toLowerCase()}@raneen.app`
      const created = await admin.auth.admin.createUser({email,password:body.password,email_confirm:true,user_metadata:{name:body.name}})
      if (created.error) throw created.error
      const id = created.data.user.id
      await admin.from('profiles').upsert({id,username:body.username,name:body.name,role:body.role,is_active:true,must_change:true})
      return Response.json({id})
    }
    if (body.action === 'update') {
      const u = await admin.auth.admin.updateUserById(body.id, body.password ? {password:body.password} : {})
      if (u.error) throw u.error
      const patch:any = {name:body.name,role:body.role,is_active:body.is_active}
      if (body.password) patch.must_change=true
      const {error} = await admin.from('profiles').update(patch).eq('id',body.id)
      if (error) throw error
      return Response.json({ok:true})
    }
    return new Response(JSON.stringify({error:'unknown action'}), {status:400})
  } catch (e) { return new Response(JSON.stringify({error:String(e)}), {status:500}) }
})
