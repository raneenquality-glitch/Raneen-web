package com.raneen.quality.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.raneen.quality.data.*
import com.raneen.quality.domain.matchesQuery
import com.raneen.quality.domain.parseNum
import kotlinx.coroutines.launch

private val OkGreen = Color(0xFF1D7A4D)
private val WarnOrange = Color(0xFFC77700)

// ───────────── الفروع ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BranchesScreen(admin: CatalogAdminRepository, onBack: () -> Unit) {
    val branches by remember { admin.branches() }.collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<BranchEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("الفروع") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { adding = true }) { Text("+ إضافة فرع") } }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (branches.isEmpty()) item { Text("مفيش فروع. اضغط + إضافة فرع.") }
            items(branches, key = { it.id }) { b ->
                Card(Modifier.fillMaxWidth().clickable { editing = b }) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(b.name, style = MaterialTheme.typography.titleMedium)
                            Text("${b.code} - ${b.region}", style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (b.isActive) "مفعّل" else "معطّل", color = if (b.isActive) OkGreen else MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
    if (adding) BranchDialog(null, admin) { adding = false }
    editing?.let { BranchDialog(it, admin) { editing = null } }
}

@Composable
private fun BranchDialog(initial: BranchEntity?, admin: CatalogAdminRepository, onClose: () -> Unit) {
    var code by remember { mutableStateOf(initial?.code ?: "") }
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var region by remember { mutableStateOf(initial?.region ?: "") }
    var active by remember { mutableStateOf(initial?.isActive ?: true) }
    var confirmDelete by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (initial == null) "إضافة فرع" else "تعديل فرع") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(code, { code = it }, label = { Text("كود الفرع") }, singleLine = true)
                OutlinedTextField(name, { name = it }, label = { Text("اسم الفرع") }, singleLine = true)
                OutlinedTextField(region, { region = it }, label = { Text("المنطقة / المدينة") }, singleLine = true)
                if (initial != null) Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = active, onCheckedChange = { active = it })
                    Spacer(Modifier.width(8.dp)); Text("الفرع مفعّل")
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val e = admin.saveBranch(initial, code, name, region, active)
                    if (e == null) onClose() else error = e
                }
            }) { Text("حفظ") }
        },
        dismissButton = {
            Row {
                if (initial != null) TextButton(onClick = {
                    if (!confirmDelete) confirmDelete = true
                    else scope.launch { val e = admin.deleteBranch(initial); if (e == null) onClose() else { error = e; confirmDelete = false } }
                }) { Text(if (confirmDelete) "تأكيد الحذف" else "حذف", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = onClose) { Text("إلغاء") }
            }
        }
    )
}

// ───────────── الأقسام والإدارات ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogScreen(admin: CatalogAdminRepository, onOpenUnit: (String, String) -> Unit, onBack: () -> Unit) {
    val units by remember { admin.units() }.collectAsState(initial = emptyList())
    var adding by remember { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Scaffold(
        topBar = { TopAppBar(title = { Text("الأقسام والضوابط") }, actions = { TextButton(onClick = onBack) { Text("رجوع") } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { adding = true }) { Text("+ قسم / إدارة") } }
    ) { padding ->
        LazyColumn(Modifier.padding(padding), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("الأقسام", style = MaterialTheme.typography.titleMedium) }
            items(units.filter { it.kind == "SECTION" }, key = { it.id }) { UnitAdminCard(admin, it) { onOpenUnit(it.id, it.name) } }
            item { Spacer(Modifier.height(8.dp)); Text("الإدارات المساعدة", style = MaterialTheme.typography.titleMedium) }
            items(units.filter { it.kind == "ADMINISTRATION" }, key = { it.id }) { UnitAdminCard(admin, it) { onOpenUnit(it.id, it.name) } }
            item {
                Spacer(Modifier.height(16.dp))
                OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("استرجاع الضوابط الأصلية") }
            }
        }
    }
    if (adding) UnitDialog(null, admin, onDeleted = {}) { adding = false }
    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        title = { Text("استرجاع الضوابط الأصلية؟") },
        text = { Text("هتتمسح كل تعديلاتك على الأقسام والضوابط وترجع لنسخة الإكسيل الأصلية. الفروع والتقارير مش هتتأثر.") },
        confirmButton = {
            TextButton(onClick = { confirmReset = false; scope.launch { admin.resetCatalog() } }) {
                Text("استرجاع", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("إلغاء") } }
    )
}

@Composable
private fun UnitAdminCard(admin: CatalogAdminRepository, u: EvaluationUnitEntity, onClick: () -> Unit) {
    val sum by remember(u.id) { admin.weightSum(u.id) }.collectAsState(initial = null)
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(u.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            WeightBadge(sum)
        }
    }
}

@Composable
private fun WeightBadge(sum: Double?) {
    val s = sum ?: 0.0
    val ok = kotlin.math.abs(s - 100.0) < 0.001
    Text("${fmtWeight(s)} / 100 ${if (ok) "✓" else "⚠"}", color = if (ok) OkGreen else WarnOrange, fontWeight = FontWeight.Bold)
}

@Composable
private fun UnitDialog(initial: EvaluationUnitEntity?, admin: CatalogAdminRepository, onDeleted: () -> Unit, onClose: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var kind by remember { mutableStateOf(initial?.kind ?: "SECTION") }
    var confirmDelete by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (initial == null) "إضافة قسم / إدارة" else "تعديل القسم") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("الاسم") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = kind == "SECTION", onClick = { kind = "SECTION" }, label = { Text("قسم") })
                    FilterChip(selected = kind == "ADMINISTRATION", onClick = { kind = "ADMINISTRATION" }, label = { Text("إدارة مساعدة") })
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = { scope.launch { val e = admin.saveUnit(initial, name, kind); if (e == null) onClose() else error = e } }) { Text("حفظ") }
        },
        dismissButton = {
            Row {
                if (initial != null) TextButton(onClick = {
                    if (!confirmDelete) confirmDelete = true
                    else scope.launch { admin.deleteUnit(initial.id); onDeleted() }
                }) { Text(if (confirmDelete) "تأكيد الحذف" else "حذف القسم", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = onClose) { Text("إلغاء") }
            }
        }
    )
}

// ───────────── تعديل قسم واحد: مجموعات + كاتجري + ضوابط ─────────────
private sealed interface Dlg {
    data class Group(val g: ProductGroupEntity?) : Dlg
    data class Category(val c: CategoryEntity?) : Dlg
    data class Control(val c: ControlEntity?, val categoryId: String) : Dlg
    object UnitEdit : Dlg
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnitEditScreen(admin: CatalogAdminRepository, unitId: String, onBack: () -> Unit) {
    val unit by remember(unitId) { admin.unit(unitId) }.collectAsState(initial = null)
    val groups by remember(unitId) { admin.groups(unitId) }.collectAsState(initial = emptyList())
    val cats by remember(unitId) { admin.categories(unitId) }.collectAsState(initial = emptyList())
    val controls by remember(unitId) { admin.controls(unitId) }.collectAsState(initial = emptyList())
    val sum by remember(unitId) { admin.weightSum(unitId) }.collectAsState(initial = null)
    var query by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf<Dlg?>(null) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(unit?.name ?: "") },
            actions = {
                TextButton(onClick = { dlg = Dlg.UnitEdit }) { Text("اسم/حذف") }
                TextButton(onClick = onBack) { Text("رجوع") }
            }
        )
    }) { padding ->
        Column(Modifier.padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("مجموع الأوزان:", Modifier.weight(1f)); WeightBadge(sum)
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true, label = { Text("بحث في الضوابط") },
                trailingIcon = { if (query.isNotEmpty()) TextButton(onClick = { query = "" }) { Text("مسح") } },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
            )
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // المجموعات
                if (query.isBlank()) {
                    item {
                        Text("المجموعات (مجموعات منتجات / ق1–ق4)", style = MaterialTheme.typography.titleSmall)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            groups.forEach { g -> AssistChip(onClick = { dlg = Dlg.Group(g) }, label = { Text(g.name) }) }
                            AssistChip(onClick = { dlg = Dlg.Group(null) }, label = { Text("+ مجموعة") })
                        }
                    }
                }
                cats.forEach { c ->
                    val shown = if (query.isBlank()) controls.filter { it.categoryId == c.id }
                    else controls.filter { it.categoryId == c.id && matchesQuery(query, c.name, it.text, it.hint, it.sortOrder.toString()) }
                    if (query.isNotBlank() && shown.isEmpty()) return@forEach
                    item(key = "c_${c.id}") {
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "${c.name}  (${fmtWeight(controls.filter { it.categoryId == c.id }.sumOf { it.maxScore })})",
                                style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f)
                            )
                            TextButton(onClick = { dlg = Dlg.Category(c) }) { Text("تعديل") }
                            TextButton(onClick = { dlg = Dlg.Control(null, c.id) }) { Text("+ ضابط") }
                        }
                    }
                    items(shown, key = { it.id }) { k ->
                        Card(Modifier.fillMaxWidth().clickable { dlg = Dlg.Control(k, k.categoryId) }) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text("${k.sortOrder}. ${k.text}")
                                    val flags = if (k.maxScore <= 0) "ضابط حصر (بدون درجة)" else listOfNotNull(
                                        "خصم ${fmtWeight(k.penaltyPerViolation)}",
                                        if (k.perGroup) "لكل مجموعة" else null,
                                        if (k.photoRequired) "📷" else null
                                    ).joinToString(" · ")
                                    Text(flags, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(if (k.maxScore <= 0) "حصر" else fmtWeight(k.maxScore), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                if (query.isBlank()) item {
                    OutlinedButton(onClick = { dlg = Dlg.Category(null) }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) { Text("+ إضافة كاتجري") }
                }
            }
        }
    }

    when (val d = dlg) {
        is Dlg.Group -> GroupDialog(d.g, unitId, admin) { dlg = null }
        is Dlg.Category -> CategoryDialog(d.c, unitId, admin) { dlg = null }
        is Dlg.Control -> ControlDialog(d.c, d.categoryId, unitId, cats, groups.isNotEmpty(), admin) { dlg = null }
        Dlg.UnitEdit -> UnitDialog(unit, admin, onDeleted = { dlg = null; onBack() }) { dlg = null }
        null -> {}
    }
}

@Composable
private fun NameDialog(
    title: String, label: String, initial: String, canDelete: Boolean,
    onSave: suspend (String) -> String?, onDelete: suspend () -> Unit, onClose: () -> Unit
) {
    var name by remember { mutableStateOf(initial) }
    var confirm by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text(label) }, singleLine = true)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = { scope.launch { val e = onSave(name); if (e == null) onClose() else error = e } }) { Text("حفظ") } },
        dismissButton = {
            Row {
                if (canDelete) TextButton(onClick = {
                    if (!confirm) confirm = true else scope.launch { onDelete(); onClose() }
                }) { Text(if (confirm) "تأكيد الحذف" else "حذف", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = onClose) { Text("إلغاء") }
            }
        }
    )
}

@Composable
private fun GroupDialog(g: ProductGroupEntity?, unitId: String, admin: CatalogAdminRepository, onClose: () -> Unit) =
    NameDialog(if (g == null) "إضافة مجموعة" else "تعديل مجموعة", "اسم المجموعة", g?.name ?: "", g != null,
        { admin.saveGroup(unitId, g, it) }, { admin.deleteGroup(g!!.id) }, onClose)

@Composable
private fun CategoryDialog(c: CategoryEntity?, unitId: String, admin: CatalogAdminRepository, onClose: () -> Unit) =
    NameDialog(if (c == null) "إضافة كاتجري" else "تعديل كاتجري", "اسم الكاتجري", c?.name ?: "", c != null,
        { admin.saveCategory(unitId, c, it) }, { admin.deleteCategory(c!!.id) }, onClose)

@Composable
private fun ControlDialog(
    initial: ControlEntity?, defaultCategoryId: String, unitId: String, cats: List<CategoryEntity>,
    hasGroups: Boolean, admin: CatalogAdminRepository, onClose: () -> Unit
) {
    var categoryId by remember { mutableStateOf(initial?.categoryId ?: defaultCategoryId) }
    var text by remember { mutableStateOf(initial?.text ?: "") }
    var hint by remember { mutableStateOf(initial?.hint ?: "") }
    var weight by remember { mutableStateOf(initial?.let { fmtWeight(it.maxScore) } ?: "") }
    var penalty by remember { mutableStateOf(initial?.let { fmtWeight(it.penaltyPerViolation) } ?: "1") }
    var photo by remember { mutableStateOf(initial?.photoRequired ?: true) }
    var perGroup by remember { mutableStateOf(initial?.perGroup ?: false) }
    var census by remember { mutableStateOf(initial != null && initial.maxScore <= 0.0) }
    var confirm by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val num = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (initial == null) "إضافة ضابط" else "تعديل ضابط") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الكاتجري", style = MaterialTheme.typography.labelMedium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    cats.forEach { c -> FilterChip(selected = categoryId == c.id, onClick = { categoryId = c.id }, label = { Text(c.name) }) }
                }
                OutlinedTextField(text, { text = it }, label = { Text("نص الضابط") }, minLines = 2)
                OutlinedTextField(hint, { hint = it }, label = { Text("ملاحظة للمراقب (اختياري)") }, minLines = 1)
                if (hasGroups) Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = census, onCheckedChange = { census = it }); Spacer(Modifier.width(8.dp)); Text("ضابط حصر (عدد من غير درجة)")
                }
                if (!census) {
                    OutlinedTextField(weight, { weight = it }, label = { Text("الوزن (الدرجة الكاملة)") }, singleLine = true, keyboardOptions = num)
                    OutlinedTextField(penalty, { penalty = it }, label = { Text("الخصم لكل مخالفة (1 عادي، 2 مضاعف)") }, singleLine = true, keyboardOptions = num)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = photo, onCheckedChange = { photo = it }); Spacer(Modifier.width(8.dp)); Text("يتطلب صورة عند المخالفة")
                    }
                    if (hasGroups) Row(verticalAlignment = Alignment.CenterVertically) {
                        Switch(checked = perGroup, onCheckedChange = { perGroup = it }); Spacer(Modifier.width(8.dp)); Text("بيتسجل على كل مجموعة لوحدها")
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    val e = admin.saveControl(unitId, initial, categoryId, text, hint, parseNum(weight), parseNum(penalty), photo, if (census) hasGroups else (perGroup && hasGroups), census)
                    if (e == null) onClose() else error = e
                }
            }) { Text("حفظ") }
        },
        dismissButton = {
            Row {
                if (initial != null) TextButton(onClick = {
                    if (!confirm) confirm = true else scope.launch { admin.deleteControl(initial.id); onClose() }
                }) { Text(if (confirm) "تأكيد الحذف" else "حذف", color = MaterialTheme.colorScheme.error) }
                TextButton(onClick = onClose) { Text("إلغاء") }
            }
        }
    )
}
